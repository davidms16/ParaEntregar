package EjeciciosParaRecuperacion;

import java.util.Scanner;

public class RetratoRobotArrays {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] peloOpciones = {"WWWWWWWWW", "\\\\\\//////", "|\"\"\"\"\"\"\"|", "|||||||||"};
        String[] ojosOpciones = {"|  O O  |", "|-(· ·)-|", "|-(o o)-|", "|  \\/  |"};
        String[] orejasNarizOpciones = {"@   J   @", "{   \"}\"", "[   j   ]", "<   ->"};
        String[] bocaOpciones = {"|  ===  |", "|   -|", "|  ___  |", "|---|"};

        // Inicializar retrato con caracteres vacíos
        String[] retrato = {"", "", "", "", ""};

        // Mostrar opciones al usuario
        mostrarOpciones("Opciones para el pelo:", peloOpciones);
        int pelo = seleccionarOpcion("Seleccione una opción para el pelo (1-4): ", 1, 4, scanner);
        retrato[0] = peloOpciones[pelo - 1];

        mostrarOpciones("Opciones para los ojos:", ojosOpciones);
        int ojos = seleccionarOpcion("Seleccione una opción para los ojos (1-4): ", 1, 4, scanner);
        retrato[1] = ojosOpciones[ojos - 1];

        mostrarOpciones("Opciones para orejas y nariz:", orejasNarizOpciones);
        int orejasNariz = seleccionarOpcion("Seleccione una opción para orejas y nariz (1-4): ", 1, 4, scanner);
        retrato[2] = orejasNarizOpciones[orejasNariz - 1];

        mostrarOpciones("Opciones para la boca:", bocaOpciones);
        int boca = seleccionarOpcion("Seleccione una opción para la boca (1-4): ", 1, 4, scanner);
        retrato[3] = bocaOpciones[boca - 1];

        retrato[4] = "\\_____/"; // Barba

        // Mostrar el retrato final
        System.out.println("\nRetrato Robot:");
        for (String parte : retrato) {
            System.out.println(parte);
        }
    }

    private static void mostrarOpciones(String mensaje, String[] opciones) {
        System.out.println(mensaje);
        for (int i = 0; i < opciones.length; i++) {
            System.out.println((i + 1) + ". \"" + opciones[i] + "\"");
        }
    }

    private static int seleccionarOpcion(String mensaje, int min, int max, Scanner scanner) {
        int opcion;
        do {
            System.out.print(mensaje);
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor, ingrese un número válido.");
                scanner.next();
            }
            opcion = scanner.nextInt();
        } while (opcion < min || opcion > max);
        return opcion;
    }
}

