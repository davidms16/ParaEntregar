package EjeciciosParaRecuperacion;

import java.util.Scanner;

public class RetratoRobot {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] peloOpciones = {"WWWWWWWWW", "\\\\\\//////", "|\"\"\"\"\"\"\"|", "|||||||||"};
        String[] ojosOpciones = {"|  O O  |", "|-(· ·)-|", "|-(o o)-|", "|  \\/  |"};
        String[] orejasNarizOpciones = {"@   J   @", "{   \"}\"", "[   j   ]", "<   ->"};
        String[] bocaOpciones = {"|  ===  |", "|   -|", "|  ___  |", "|---|"};

        System.out.println("Opciones para el pelo:");
        for (int i = 0; i < peloOpciones.length; i++) {
            System.out.println((i + 1) + ". \"" + peloOpciones[i] + "\"");
        }

        int pelo = solicitarOpcion("Seleccione una opción para el pelo (1-4): ", 1, 4, scanner);

        System.out.println("\nOpciones para los ojos:");
        for (int i = 0; i < ojosOpciones.length; i++) {
            System.out.println((i + 1) + ". \"" + ojosOpciones[i] + "\"");
        }

        int ojos = solicitarOpcion("Seleccione una opción para los ojos (1-4): ", 1, 4, scanner);

        System.out.println("\nOpciones para orejas y nariz:");
        for (int i = 0; i < orejasNarizOpciones.length; i++) {
            System.out.println((i + 1) + ". \"" + orejasNarizOpciones[i] + "\"");
        }

        int orejasNariz = solicitarOpcion("Seleccione una opción para orejas y nariz (1-4): ", 1, 4, scanner);

        System.out.println("\nOpciones para la boca:");
        for (int i = 0; i < bocaOpciones.length; i++) {
            System.out.println((i + 1) + ". \"" + bocaOpciones[i] + "\"");
        }

        int boca = solicitarOpcion("Seleccione una opción para la boca (1-4): ", 1, 4, scanner);

        System.out.println("\nLa barbilla estará formada siempre por los caracteres: \n\\_____/");

        String retrato = peloOpciones[pelo - 1] + "\n" + ojosOpciones[ojos - 1] +
                "\n" + orejasNarizOpciones[orejasNariz - 1] + "\n" + bocaOpciones[boca - 1] + "\n\\_____/";

        System.out.println("\nRetrato Robot:");
        System.out.println(retrato);
    }

    private static int solicitarOpcion(String mensaje, int min, int max, Scanner scanner) {
        int opcion;
        do {
            System.out.print(mensaje);
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor, ingrese un número válido.");
                scanner.next();
            }
            opcion = scanner.nextInt();
        } while (opcion < min || opcion > max);
        return opcion;
    }
}