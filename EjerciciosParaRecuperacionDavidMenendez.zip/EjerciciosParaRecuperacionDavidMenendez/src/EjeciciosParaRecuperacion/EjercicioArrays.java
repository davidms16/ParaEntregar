package EjeciciosParaRecuperacion;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class EjercicioArrays {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Inicialización de mesas con valores aleatorios entre 0 y 4
        int[] mesas = new int[10];
        for (int i = 0; i < mesas.length; i++) {
            mesas[i] = random.nextInt(5); // valores entre 0 y 4
        }

        while (true) {
            System.out.println("Estado actual de las mesas: " + Arrays.toString(mesas));

            System.out.print("¿Cuantos son en el grupo? (0 para salir): ");
            int clientes = scanner.nextInt();

            if (clientes == 0) {
                System.out.println("Gracias por usar nuestra aplicación. ¡Hasta luego!");
                break;
            }

            if (clientes > 4) {
                System.out.println("Lo siento, no admitimos grupos de más de cuatro personas. Haga grupos de cuatro como máximo e intente de nuevo.");
                continue;
            }

            // Buscar mesa disponible
            boolean mesaEncontrada = false;
            for (int i = 0; i < mesas.length; i++) {
                if (mesas[i] == 0) {
                    mesas[i] = clientes;
                    mesaEncontrada = true;
                    break;
                }
            }

            // Si no hay mesa disponible, buscar hueco para el grupo
            if (!mesaEncontrada) {
                for (int i = 0; i < mesas.length; i++) {
                    if (mesas[i] + clientes <= 4) {
                        mesas[i] += clientes;
                        mesaEncontrada = true;
                        break;
                    }
                }
            }

            if (!mesaEncontrada) {
                System.out.println("Lo siento, no hay mesas disponibles para su grupo en este momento.");
            }
        }
    }
}

