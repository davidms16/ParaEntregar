package EjeciciosParaRecuperacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class AnimacionPoligono extends JFrame implements ActionListener, KeyListener {

	private static final long serialVersionUID = 1L;
	private static final int ANCHO_VENTANA = 800;
    private static final int ALTO_VENTANA = 600;

    private int lados = 5; // Número inicial de lados del polígono
    private double radio = 1795.5; // Radio de la circunferencia
    private double velocidad = 17.313; // Velocidad lineal en metros por segundo

    private double angulo = 0; // Ángulo de rotación del polígono
    private double direccion = 1; // Dirección de desplazamiento (+1 derecha, -1 izquierda)

    private Timer timer;

    public AnimacionPoligono() {
        setTitle("Animación Polígono");
        setSize(ANCHO_VENTANA, ALTO_VENTANA);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        addKeyListener(this);

        timer = new Timer(30, this); // Temporizador para la animación
        timer.start();
    }

    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;

        int centroX = ANCHO_VENTANA / 2;
        int centroY = ALTO_VENTANA / 2;

        // Dibujar línea horizontal en el centro de la pantalla
        g2d.drawLine(0, centroY, ANCHO_VENTANA, centroY);

        // Calcular posición del polígono
        int x = (int) (centroX + radio * Math.cos(Math.toRadians(angulo)));
        int y = (int) (centroY + radio * Math.sin(Math.toRadians(angulo)));

        // Dibujar polígono
        int[] xPoints = new int[lados];
        int[] yPoints = new int[lados];

        for (int i = 0; i < lados; i++) {
            double theta = 2 * Math.PI * i / lados;
            xPoints[i] = (int) (x + radio * Math.cos(theta));
            yPoints[i] = (int) (y + radio * Math.sin(theta));
        }

        g2d.drawPolygon(xPoints, yPoints, lados);

        // Actualizar posición y dirección del polígono
        angulo += velocidad * direccion / radio;

        if (x <= 0 || x >= ANCHO_VENTANA) {
            direccion *= -1; // Cambiar dirección al chocar con los laterales
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AnimacionPoligono animacion = new AnimacionPoligono();
            animacion.setVisible(true);
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // No se necesita implementar para este ejemplo
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && lados < 19) {
            lados++;
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT && lados > 3) {
            lados--;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // No se necesita implementar para este ejemplo
    }
}