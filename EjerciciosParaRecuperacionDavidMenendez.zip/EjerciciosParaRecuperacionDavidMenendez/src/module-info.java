/**
 * 
 */
/**
 * @author david
 *
 */
module EjerciciosParaRecuperacionDavidMenendez {
	requires java.desktop;
}